﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CursoDesktop
{
    public class Cliente
    {
        public int Codigo { get; set; }
        public String Nome { get; set; }
        public int Idade { get; set; }
        public String Telefone { get; set; }
        public char Sexo { get; set; }
        public String Endereco { get; set; }
    }
}
